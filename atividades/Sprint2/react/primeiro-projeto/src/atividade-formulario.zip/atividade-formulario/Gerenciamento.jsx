export function Gerenciamento() {
  return (
    <div>
      <button>Desabilitar formulario</button>
    </div>
  );
}