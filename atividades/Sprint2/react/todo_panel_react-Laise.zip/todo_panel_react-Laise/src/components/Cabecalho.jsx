import React from 'react';

export function Cabecalho() {
  return (
    <header>
      <h1>Lista de Tarefas</h1>
    </header>
  );
}
